<?php
// ai/secrets.php
return [
  'GROQ_API_KEY' => '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',
  'GROQ_MODEL'   => 'llama-3.1-8b-instant',
  'GROQ_BASE'    => 'https://api.groq.com/openai/v1',
];
