<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="stylesheet" href="./style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <title>Document</title>
</head>
<body>
  <nav>
    <ul>
      <div class="logo">
        <img src="./ai.jpg" alt="AI-soultions logo" />
      </div>
    </ul>
    <ul>
      <li><a href="./index.php" class="links">Home</a></li>

      <!-- Dropdown for Our Solutions -->
      <li class="dropdown">
        <a href="./solutions.php" class="links" aria-haspopup="true" aria-expanded="false">Our Solutions</a>
        <ul class="dropdown-menu" role="menu" aria-label="Our Solutions submenu">
          <li><a href="./solutions.php" data-tab="ai" role="menuitem">AI Virtual Assistant</a></li>
          <li><a href="./solutions1.php" data-tab="prototyping" role="menuitem">Rapid Prototyping</a></li>
          <li><a href="./solutions2.php" data-tab="analytics" role="menuitem">Analytics & Insights</a></li>
          <li><a href="./solutions3.php" data-tab="security" role="menuitem">Security by Design</a></li>
        </ul>
      </li>

      <li><a href="./services.php" class="links">Services</a></li>
      <li><a href="./blogs.php" class="links">Blogs </a></li>
      <li><a href="./events.php" class="links">Events</a></li>
      <li><a href="./photos.php" class="links">Photos</a></li>
      <li><a href="./testimonals.php" class="links">Portfolios</a></li>
      <li><a href="./about.php" class="links">About us</a></li>

      <li><button class="contact-btn"><a href="./contact.php">Contact</a></button></li>
    </ul>
  </nav>

<!-- ===== HERO VIDEO (replaces old image hero) ===== -->
<div class="hero">
  <div class="video-wrap">
    <iframe
      src="https://www.youtube.com/embed/3gznkwW0MnE?si=NbCF92AWtwsuCGk1&autoplay=1&mute=1&playsinline=1&controls=0&modestbranding=1&rel=0&loop=1&playlist=3gznkwW0MnE"
      title="AI intro video"
      frameborder="0"
      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
      allowfullscreen
    ></iframe>
  </div>
</div>



 


  <!-- ACTIVE LINK SCRIPT -->
  <script>
    (function () {
      // Normalize a URL/href to its filename (handles /, ./, queries, hashes)
      function normalize(u) {
        try {
          const url = u.includes('://') ? new URL(u) : new URL(u, location.href);
          let file = url.pathname.split('/').filter(Boolean).pop() || '';
          if (!file) file = 'index.php';
          if (file.toLowerCase() === 'index.html') file = 'index.php';
          return file.toLowerCase();
        } catch { return ''; }
      }

      const currentFile = normalize(location.href);

      document.querySelectorAll('nav a[href]').forEach(a => {
        const hrefFile = normalize(a.getAttribute('href'));
        if (!hrefFile) return;

        if (hrefFile === currentFile) {
          a.classList.add('active');
          a.setAttribute('aria-current', 'page');

          // If link is inside the dropdown, also mark parent trigger
          const dd = a.closest('.dropdown');
          if (dd) dd.querySelector(':scope > a.links')?.classList.add('active');
        }

        // Instant visual feedback before navigation (optional)
        a.addEventListener('click', () => {
          document.querySelectorAll('nav a.active').forEach(x => x.classList.remove('active'));
          a.classList.add('active');
          const dd = a.closest('.dropdown');
          if (dd) dd.querySelector(':scope > a.links')?.classList.add('active');
        });
      });

      // Safety: Home active on root
      if (currentFile === 'index.php') {
        const home = document.querySelector('nav a[href$="index.php"]');
        if (home) {
          home.classList.add('active');
          home.setAttribute('aria-current', 'page');
        }
      }
    })();
  </script>

  

  <script>
    // Dropdown behavior
    const dropdown = document.querySelector('nav .dropdown');
    if (dropdown) {
      const trigger = dropdown.querySelector('a.links');
      const menu = dropdown.querySelector('.dropdown-menu');

      trigger.addEventListener('click', (e) => {
        if (!dropdown.classList.contains('open')) e.preventDefault();
        const nowOpen = !dropdown.classList.contains('open');
        dropdown.classList.toggle('open', nowOpen);
        trigger.setAttribute('aria-expanded', nowOpen ? 'true' : 'false');
      });

      document.addEventListener('click', (e) => {
        if (!dropdown.contains(e.target)) {
          dropdown.classList.remove('open');
          trigger.setAttribute('aria-expanded', 'false');
        }
      });

      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          dropdown.classList.remove('open');
          trigger.setAttribute('aria-expanded', 'false');
          trigger.focus();
        }
      });
    }
  </script>

  <section class="part2">
    <h1 class="h1_one">Driving Smarter Work Through AI</h1>
    <p class="p_three">For years, AI-Solution has been at the forefront of leveraging artificial intelligence to transform the digital employee experience. <br />From developing AI-powered virtual assistants to delivering affordable prototyping tools, the company focuses on not just creating innovative solutions, <br /> but also enabling organizations to adopt them effectively. Today, AI-Solution helps businesses streamline workflows, accelerate innovation, <br />and empower employees to thrive in an increasingly digital workplace.</p>
  </section>

  <div class="img_container2">
    <div class="container3">
      <img src="./industry.png" alt="" />
      <section>
        <h1 class="img_heading">5+ </h1>
        <h2 class="img_subheading">Industries Served</h2>
        <p class="img_detail">Our AI solutions empower diverse industries including IT, finance, healthcare, and education to innovate faster.</p>
      </section>
    </div>

    <div class="container3">
      <img src="./prototype.png" alt="" />
      <section>
        <h1 class="img_heading">10+</h1>
        <h2 class="img_subheading">Successful Prototypes Delivered</h2>
        <p class="img_detail">We’ve built and tested multiple AI-powered prototypes that help businesses validate ideas rapidly and affordably.</p>
      </section>
    </div>

    <div class="container3">
      <img src="./inquiries.jpg" alt="" />
      <section>
        <h1 class="img_heading">5000+</h1>
        <h2 class="img_subheading">Enquiries Handled </h2>
        <p class="img_detail">Our AI-powered assistant ensures smooth handling of customer queries with accuracy and speed.</p>
      </section>
    </div>

    <div class="container3">
      <img src="./virtual.jpg" alt="" />
      <section>
        <h1 class="img_heading">24/7</h1>
        <h2 class="img_subheading">Virtual Assistance</h2>
        <p class="img_detail">Always available to support employees and customers, reducing downtime and boosting efficiency.</p>
      </section>
    </div>
  </div>

  <div class="img_container3">
    <section class="solution_part">
      <h1 class="hone">Our Solutions</h1>
      <p class="ptwo">
        Built on innovation, intelligence, and security, our AI-driven solutions are designed to
        enhance the digital employee experience. From virtual assistants that streamline support
        to rapid prototyping tools that accelerate innovation, we empower organizations to work
        smarter and adapt faster. With built-in analytics and OWASP-aligned security, we ensure
        our partners can confidently transform challenges into opportunities.
      </p>

      <!-- Tabs -->
      <div class="solutions_types" role="tablist" aria-label="Solutions tabs">
        <a class="active" href="#" data-tab="ai" role="tab" aria-selected="true">AI Virtual Assistant</a>
        <a href="#" data-tab="prototyping" role="tab" aria-selected="false">Rapid Prototyping</a>
        <a href="#" data-tab="analytics" role="tab" aria-selected="false">Analytics & Insights</a>
        <a href="#" data-tab="security" role="tab" aria-selected="false">Security by Design</a>
      </div>
    </section>

    <!-- Tabs content -->
    <div class="solutions-wrap">
      <div class="solution-tab active" id="ai" role="tabpanel">
        <div class="solution-block">
          <div class="solution-image">
            <img src="./aivirtual.avif" alt="AI Virtual Assistant illustration" />
          </div>
          <div class="solution-content">
            <h2 class="solution-title">AI Virtual Assistant</h2>
            <p class="solution-text">
              Our AI Virtual Assistant is an always-available digital helper for employees and customers.
              It answers enquiries, automates repetitive tasks, and routes requests to the right teams.
              With 24/7 availability and faster responses, it keeps work moving smoothly.
            </p>
            <button class="des_btn"><a href="#">Discover More</a></button>

            <div class="usecase-card">
              <h3>USE CASE</h3>
              <h2>SmartHelp</h2>
              <p>SmartHelp provides instant, reliable support across channels. It handles thousands of enquiries daily, reducing workload for support teams and delivering consistent resolutions.</p>
              <div class="numerics">
                <div><h1>5000+</h1><p>Enquiries Handled</p></div>
                <div><h1>24/7</h1><p>Availability</p></div>
                <div><h1>60%</h1><p>Faster Response Times</p></div>
                <div><h1>90%</h1><p>Automated Resolution</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="solution-tab" id="prototyping" role="tabpanel">
        <div class="solution-block">
          <div class="solution-image">
            <img src="./prototype.png" alt="Rapid Prototyping illustration" />
          </div>
          <div class="solution-content">
            <h2 class="solution-title">Rapid Prototyping</h2>
            <p class="solution-text">Validate ideas quickly with low-cost AI prototypes. We deliver focused proof-of-concepts so teams can test functionality, gather feedback, and decide what to scale—faster and with less risk.</p>
            <button class="des_btn"><a href="#">Discover More</a></button>

            <div class="usecase-card">
              <h3>USE CASE</h3>
              <h2>QuickBuild</h2>
              <p>QuickBuild compresses months of exploration into weeks. Product teams iterate live with users, validate assumptions, and prioritize features based on evidence—not guesswork.</p>
              <div class="numerics">
                <div><h1>10+</h1><p>Prototypes Delivered</p></div>
                <div><h1>70%</h1><p>Faster Time-to-Market</p></div>
                <div><h1>40%</h1><p>Cost Reduction</p></div>
                <div><h1>~2 wks</h1><p>Avg. Delivery</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="solution-tab" id="analytics" role="tabpanel">
        <div class="solution-block">
          <div class="solution-image">
            <img src="./analytics.jpg" alt="Analytics and Insights illustration" />
          </div>
          <div class="solution-content">
            <h2 class="solution-title">Analytics & Insights</h2>
            <p class="solution-text">Turn data into decisions. Real-time dashboards track enquiries, workflows, and performance, revealing trends and bottlenecks so leaders can allocate resources and improve outcomes.</p>
            <button class="des_btn"><a href="#">Discover More</a></button>

            <div class="usecase-card">
              <h3>USE CASE</h3>
              <h2>Insight360</h2>
              <p>Insight360 unifies operational metrics and conversation signals into a single view, giving teams clear visibility to act quickly and confidently.</p>
              <div class="numerics">
                <div><h1>100%</h1><p>Real-Time Tracking</p></div>
                <div><h1>30%</h1><p>Productivity Lift</p></div>
                <div><h1>50+</h1><p>Metrics Monitored</p></div>
                <div><h1>1 View</h1><p>Unified Dashboard</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="solution-tab" id="security" role="tabpanel">
        <div class="solution-block">
          <div class="solution-image">
            <img src="./security.jpg" alt="Security by Design illustration" />
          </div>
          <div class="solution-content">
            <h2 class="solution-title">Security by Design</h2>
            <p class="solution-text">Every solution follows OWASP best practices with encryption and GDPR-aware handling. Security is built-in from day one so teams can adopt AI with confidence.</p>
            <button class="des_btn"><a href="#">Discover More</a></button>

            <div class="usecase-card">
              <h3>USE CASE</h3>
              <h2>SafeCore</h2>
              <p>SafeCore embeds secure patterns across authentication, data storage, and integrations, minimizing risk while maintaining agility.</p>
              <div class="numerics">
                <div><h1>100%</h1><p>OWASP-Aligned</p></div>
                <div><h1>GDPR</h1><p>Compliance</p></div>
                <div><h1>0</h1><p>Data Breaches</p></div>
                <div><h1>100%</h1><p>Encrypted at Rest/In-Transit</p></div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div><!-- /.solutions-wrap -->
  </div><!-- /.img_container3 -->

  <!-- Blogs Section -->
  <section id="blogs" class="light">
    <div class="container">
      <h2>From Our Blog</h2>
      <p class="muted">Latest insights and updates from AI-Solutions.</p>

      <div class="cards three">
        <a class="card" href="blogs.php">
          <img src="./blog1.jpg" alt="AI in the workplace" />
          <h3>AI in the Workplace</h3>
          <p>How virtual assistants are changing productivity.</p>
        </a>
        <a class="card" href="blogs.php">
          <img src="./blog2.jpg" alt="Rapid Prototyping" />
          <h3>Rapid Prototyping</h3>
          <p>Faster innovation cycles with AI-driven POCs.</p>
        </a>
        <a class="card" href="blogs.php">
          <img src="./blog3.jpg" alt="Security Insights" />
          <h3>Security Insights</h3>
          <p>Keeping AI solutions safe and compliant.</p>
        </a>
      </div>

      <a href="blogs.php" class="btn">View all blogs</a>
    </div>
  </section>

  <!-- Events Section -->
  <section id="events">
    <div class="container">
      <h2>Events</h2>
      <p class="muted">Upcoming and past highlights.</p>

      <div class="cards three">
        <a class="card" href="events.php">
          <img src="./aisummit.jpg" alt="AI Summit 2025" />
          <h3>AI Summit 2025</h3>
          <p>Join us in showcasing smart solutions for business.</p>
        </a>
        <a class="card" href="events.php">
          <img src="./techexpo.jpg" alt="Tech Expo" />
          <h3>Tech Expo</h3>
          <p>AI-Solutions at the forefront of digital innovation.</p>
        </a>
        <a class="card" href="events.php">
          <img src="./workshops.jpg" alt="Workshop" />
          <h3>AI Workshop</h3>
          <p>Hands-on training to empower your teams.</p>
        </a>
      </div>

      <a href="events.php" class="btn">See all events</a>
    </div>
  </section>



  <!-- ===== Services Overview ===== -->
<section id="services-overview" class="light">
  <div class="container">
    <h2>Our Services</h2>
    <p class="muted">
      Explore AI-powered solutions — from Virtual Assistants to Rapid Prototyping and secure Digital Experience dashboards.
    </p>

    <div class="cards three">
      <a class="card" href="services.php">
        <img src="./ailaptop.png" alt="AI Virtual Assistant" />
        <h3>AI Virtual Assistant</h3>
        <p>Always-on digital helper for employees and customers — fast responses, smooth workflows.</p>
      </a>

      <a class="card" href="services.php">
        <img src="./prototype.png" alt="Rapid Prototyping" />
        <h3>Rapid Prototyping</h3>
        <p>Validate ideas quickly with cost-effective proofs of concept to reduce risk and save time.</p>
      </a>

      <a class="card" href="services.php">
        <img src="./analytics.jpg" alt="Analytics and Insights" />
        <h3>Analytics & Insights</h3>
        <p>Turn data into decisions with real-time dashboards and actionable insights.</p>
      </a>
    </div>

    <a href="services.php" class="btn">See all services</a>
  </div>
</section>

<!-- ===== Photos Overview ===== -->
<section id="photos-overview">
  <div class="container">
    <h2>Event Photos</h2>
    <p class="muted">Glimpses from our recent workshops, showcases, and AI solution launches.</p>

    <div class="gallery-preview">
      <img src="./images1.png" alt="Demo day">
      <img src="./images2.png" alt="Prototype walkthrough">
      <img src="./images3.png" alt="Q&A session">
      <img src="./images4.png" alt="Networking event">
    </div>

    <a href="photos.php" class="btn">View full gallery</a>
  </div>
</section>

  <section id="testimonials" class="light">
    <div class="container">
      <h2>Testimonials</h2>
      <p class="muted">Trusted by teams across industries.</p>

    <div class="t-wrapper">
      <div class="t-preview">
        <img src="./samantha.jpg" alt="Photo of Samantha Lee" class="t-avatar" />
        <blockquote>“DocuMind has completely changed how our teams handle documentation… we save at least 30% of our time weekly.”</blockquote>
        <cite>— Samantha Lee, Operations Manager</cite>
        <div class="t-stars">⭐ 4.7 / 5</div>
      </div>

      <div class="t-preview">
        <img src="./rajesh.jpg" alt="Photo of Rajesh Patel" class="t-avatar" />
        <blockquote>“FinSight has given us unprecedented visibility into finances… the predictive budgeting tool saved us from overspending.”</blockquote>
        <cite>— Rajesh Patel, CFO</cite>
        <div class="t-stars">⭐ 4.9 / 5</div>
      </div>
    </div>

    <a class="btn" href="testimonals.php">View More</a>
    </div>
  </section>


  <!-- ================== About Us Overview ================== -->
<section id="about-overview">
  <div class="container">
    <h2>About AI-Solutions</h2>
    <p class="muted">
      We are a forward-looking AI innovation hub delivering smarter workplaces,
      faster product development, and actionable analytics. Our mission is to empower
      organizations with cutting-edge AI tools and seamless user experiences.
    </p>

    <div class="about-cards">
      <div class="card">
        <img src="./mission.jpg" alt="Our Mission">
        <h3>Our Mission</h3>
        <p>Helping businesses transform with AI by reducing repetitive work and accelerating growth.</p>
      </div>

      <div class="card">
        <img src="./vision.jpg" alt="Our Vision">
        <h3>Our Vision</h3>
        <p>To be a global leader in AI-driven solutions, inspiring innovation and trust worldwide.</p>
      </div>

      <div class="card">
        <img src="./values.jpg" alt="Our Values">
        <h3>Our Values</h3>
        <p>Integrity, collaboration, grit, and innovation guide our journey to create real impact.</p>
      </div>
    </div>

    <div class="about-cta">
  <a href="./about.php" class="btn-primary" aria-label="Read more about AI-Solutions on the About page">
    Learn more about us
  </a>
</div>

  </div>
</section>

  <!-- Tabs JS -->
  <script>
    const links = document.querySelectorAll('.solutions_types a');
    const tabs  = document.querySelectorAll('.solution-tab');

    links.forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        const target = link.dataset.tab;

        links.forEach(l => {
          l.classList.toggle('active', l === link);
          l.setAttribute('aria-selected', l === link ? 'true' : 'false');
        });

        tabs.forEach(t => t.classList.toggle('active', t.id === target));
      });
    });
  </script>

  <!-- Footer -->
  <footer>
    <div class="footer-container">
      <div class="footer-column">
        <h3>Company</h3>
        <ul>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
        </ul>
      </div>

      <div class="footer-column">
        <h3>Our Solutions</h3>
        <ul>
          <li><a href="solutions.php">AI Virtual Assistant</a></li>
          <li><a href="solutions.php">Rapid Prototyping</a></li>
          <li><a href="solutions.php">Analytics & Insights</a></li>
          <li><a href="solutions.php">Security by Design</a></li>
        </ul>
      </div>

      <div class="footer-column">
        <h3>Resources</h3>
        <ul>
          <li><a href="blogs.php">Blogs</a></li>
          <li><a href="events.php">Events</a></li>
          <li><a href="testimonials.php">Testimonials</a></li>
        </ul>
      </div>

      <div class="footer-column">
        <h3>Connect</h3>
        <div class="footer-socials">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-linkedin-in"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>

    <div class="footer-bottom">
      <p>© 2025 <span class="brand">AI-Solutions</span>. All rights reserved.</p>
    </div>
  </footer>

  <!-- (Your assistant/widget scripts unchanged below) -->
  <link rel="stylesheet" href="ai-assistant.css" />
  <script src="ai-assistant.js"></script>

  <script>
    const pageType = (() => {
      const path = location.pathname.toLowerCase();
      if (path.includes('/contact')) return 'contact';
      if (path === '/' || path === '/index.php') return 'home';
      return 'other';
    })();

    if (window.AIAssistant && typeof AIAssistant.init === 'function') {
      AIAssistant.init({
        mount: '#ai-assistant-root',
        page: pageType,
        brandName: 'AI-Solutions',
        welcomeDelayMs: 5000,
        suppressWelcomeHours: 24,
        faqEndpoint: null,
        primaryActions: [
          { label: 'Services', href: '/services' },
          { label: 'Events',   href: '/events' },
          { label: 'Contact',  href: '/contact' }
        ],
        contactForm: pageType === 'contact' ? {
          formSelector: '#contact-form',
          fields: {
            name:   'input[name="name"]',
            email:  'input[name="email"]',
            phone:  'input[name="phone"]',
            company:'input[name="company"]',
            country:'select[name="country"]',
            title:  'input[name="job_title"]',
            detail: 'textarea[name="job_details"]'
          }
        } : null
      });
    }
  </script>

<!-- ===== Pro AI Chat (drop-in) — paste just before </body> ===== -->
<script>
(function(){
  const ENDPOINT = 'ai/ai-chat-widget.php'; // <-- adjust if your endpoint lives elsewhere

  // ---------- Styles ----------
  const css = `
  :root{
    --ai-brand:#2563eb; --ai-brand-2:#7c3aed;
    --ai-bg:#0b1020; --ai-panel:#0e1426; --ai-ghost:#111831;
    --ai-text:#e6ecff; --ai-muted:#a8b3cf;
    --ai-user:#1f6feb; --ai-bot:#2b3a67;
    --ai-ring: 0 0 0 3px rgba(37,99,235,.25);
    --ai-radius:18px; --ai-shadow:0 14px 48px rgba(0,0,0,.45);
  }
  #aiFab{
    position:fixed; right:20px; bottom:20px; z-index:10000;
    width:56px; height:56px; border-radius:50%;
    border:0; cursor:pointer; display:grid; place-items:center;
    background: linear-gradient(135deg, var(--ai-brand), var(--ai-brand-2));
    color:#fff; box-shadow: var(--ai-shadow);
    transition: transform .15s ease, box-shadow .2s ease, opacity .2s;
  }
  #aiFab:hover{ transform: translateY(-1px); box-shadow: 0 18px 60px rgba(0,0,0,.55);}
  #aiFab svg{ width:26px; height:26px; }
  #aiFab .ai-badge{
    position:absolute; top:-2px; right:-2px; width:12px; height:12px; border-radius:50%;
    background:#22c55e; outline:3px solid #fff; display:none;
  }

  #aiChatPanel{
    position:fixed; right:20px; bottom:88px; z-index:10000;
    width:380px; max-width:calc(100vw - 32px); height:560px; max-height:calc(100vh - 120px);
    background: linear-gradient(180deg, var(--ai-panel), var(--ai-ghost));
    border:1px solid rgba(108,130,179,.25); border-radius: var(--ai-radius);
    box-shadow: var(--ai-shadow); display:none; overflow:hidden;
    transform-origin: bottom right; animation: ai-pop .18s ease;
  }
  @keyframes ai-pop { from { transform:scale(.98); opacity:.0 } to { transform:scale(1); opacity:1 } }

  .ai-head{
    display:flex; align-items:center; justify-content:space-between;
    padding:10px 12px; background: linear-gradient(135deg, rgba(37,99,235,.28), rgba(124,58,237,.22));
    border-bottom:1px solid rgba(108,130,179,.2);
  }
  .ai-title{ display:flex; align-items:center; gap:8px; color:#fff; font:600 14.5px/1.2 system-ui,Segoe UI,Roboto,Arial}
  .ai-title .ai-dot{ width:9px; height:9px; border-radius:50%; background:#22c55e; box-shadow:0 0 0 3px rgba(34,197,94,.2)}
  .ai-actions button{
    display:inline-grid; place-items:center; width:34px; height:34px; border-radius:10px;
    border:0; background:transparent; color:#dbe4ff; cursor:pointer;
  }
  .ai-actions button:hover{ background:rgba(255,255,255,.06) }
  .ai-actions svg{ width:18px; height:18px }

  .ai-body{ display:flex; flex-direction:column; height:calc(100% - 54px); }
  .ai-messages{
    flex:1; overflow:auto; padding:14px 14px 8px; scrollbar-width:thin; color:var(--ai-text);
  }
  .ai-row{ display:flex; margin:8px 0; gap:8px; }
  .ai-row.user{ justify-content:flex-end }
  .ai-bubble{
    max-width:78%; padding:10px 12px; border-radius:14px;
    background:#182341; color:#e9edff; font:14px/1.4 system-ui,Segoe UI,Roboto,Arial;
    box-shadow: 0 6px 22px rgba(0,0,0,.25); white-space:pre-wrap; word-wrap:break-word;
  }
  .ai-row.user .ai-bubble{
    background: linear-gradient(135deg, #1f6feb, #2563eb);
  }
  .ai-row.bot .ai-bubble{
    background: linear-gradient(135deg, #243253, #2b3a67);
  }
  .ai-time{ display:block; font-size:11px; color:var(--ai-muted); margin-top:4px; }

  .ai-typing{ display:inline-flex; gap:4px; align-items:center }
  .ai-typing i{ width:6px; height:6px; border-radius:50%; background:#c7d2fe; opacity:.45; animation: ai-dots 1.2s infinite }
  .ai-typing i:nth-child(2){ animation-delay:.15s } .ai-typing i:nth-child(3){ animation-delay:.3s }
  @keyframes ai-dots{ 0%,80%,100%{ transform:translateY(0)} 40%{ transform:translateY(-3px)} }

  .ai-input{
    display:flex; gap:8px; padding:10px; border-top:1px solid rgba(108,130,179,.18); background:rgba(12,18,34,.6);
  }
  .ai-input input{
    flex:1; padding:11px 12px; border-radius:12px; border:1px solid rgba(108,130,179,.25);
    background:#0b1120; color:#e8eeff; font:14px system-ui,Segoe UI,Roboto,Arial; outline:none;
  }
  .ai-input input:focus{ box-shadow: var(--ai-ring) }
  .ai-input button{
    padding:0 14px; border-radius:12px; border:0; cursor:pointer; color:#fff;
    background: linear-gradient(135deg, var(--ai-brand), var(--ai-brand-2));
    display:inline-grid; place-items:center; min-width:44px;
  }
  .ai-input button[disabled]{ opacity:.65; cursor:not-allowed }

  /* Mobile tweaks */
  @media (max-width: 480px){
    #aiChatPanel{ right:12px; bottom:84px; width:calc(100vw - 24px); height:60vh }
    #aiFab{ right:12px; bottom:12px }
  }`;

  const style = document.createElement('style');
  style.id = 'ai-chat-embed-styles';
  style.textContent = css;
  document.head.appendChild(style);

  // ---------- DOM ----------
  const fab = document.createElement('button');
  fab.id = 'aiFab';
  fab.setAttribute('aria-label','Open chat');
  fab.innerHTML = `
    <span class="ai-badge" aria-hidden="true"></span>
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 6.5C4 5.12 5.12 4 6.5 4h11A2.5 2.5 0 0 1 20 6.5v7A2.5 2.5 0 0 1 17.5 16H12l-3.8 3c-.7.55-1.7.03-1.7-.83V16H6.5A2.5 2.5 0 0 1 4 13.5v-7Z" fill="currentColor"/>
    </svg>`;
  document.body.appendChild(fab);

  const panel = document.createElement('div');
  panel.id = 'aiChatPanel';
  panel.innerHTML = `
    <div class="ai-head">
      <div class="ai-title"><span class="ai-dot" aria-hidden="true"></span> AI Assistant</div>
      <div class="ai-actions">
        <button id="aiMinBtn" title="Minimize" aria-label="Minimize">
          <svg viewBox="0 0 24 24"><path fill="currentColor" d="M5 12h14v2H5z"/></svg>
        </button>
        <button id="aiCloseBtn" title="Close" aria-label="Close">
          <svg viewBox="0 0 24 24"><path fill="currentColor" d="M18.3 5.71 12 12l6.3 6.29-1.42 1.42L10.59 13.41 4.29 19.71 2.87 18.29 9.17 12 2.87 5.71 4.29 4.29 10.59 10.59 16.88 4.29z"/></svg>
        </button>
      </div>
    </div>
    <div class="ai-body">
      <div class="ai-messages" id="aiMsgs" role="log" aria-live="polite" aria-label="Chat messages"></div>
      <form class="ai-input" id="aiForm">
        <input id="aiInput" type="text" placeholder="Type a message…" autocomplete="off" />
        <button id="aiSend" type="submit" title="Send">
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>
        </button>
      </form>
    </div>`;
  document.body.appendChild(panel);

  // ---------- Logic ----------
  const msgsEl = panel.querySelector('#aiMsgs');
  const form   = panel.querySelector('#aiForm');
  const input  = panel.querySelector('#aiInput');
  const sendBtn= panel.querySelector('#aiSend');
  const minBtn = panel.querySelector('#aiMinBtn');
  const closeBtn = panel.querySelector('#aiCloseBtn');
  const badge  = fab.querySelector('.ai-badge');

  let open = false;
  const history = []; // [{role:'user'|'assistant', content:'...'}]

  function nowTime(){
    const d = new Date();
    return d.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
  }

  function addMsg(role, text, isTyping=false){
    const row = document.createElement('div');
    row.className = `ai-row ${role}`;
    const bubble = document.createElement('div');
    bubble.className = 'ai-bubble';
    if (isTyping){
      bubble.innerHTML = '<span class="ai-typing" aria-label="Assistant is typing"><i></i><i></i><i></i></span>';
    } else {
      bubble.textContent = text;
    }
    const time = document.createElement('span');
    time.className = 'ai-time';
    time.textContent = nowTime();
    bubble.appendChild(time);
    row.appendChild(bubble);
    msgsEl.appendChild(row);
    msgsEl.scrollTop = msgsEl.scrollHeight;
    return {row, bubble};
  }

  function openPanel(){
    panel.style.display = 'block';
    open = true; badge.style.display = 'none';
    setTimeout(()=>input.focus(), 0);
  }
  function closePanel(){
    panel.style.display = 'none';
    open = false;
  }

  fab.addEventListener('click', openPanel);
  minBtn.addEventListener('click', closePanel);
  closeBtn.addEventListener('click', closePanel);
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape' && open) closePanel(); });

  // Greeting message (once)
  addMsg('bot', 'Hi! How can I help you today?');

  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const text = input.value.trim();
    if(!text) return;
    input.value = ''; input.focus();
    history.push({role:'user', content:text});
    addMsg('user', text);

    // show typing
    sendBtn.disabled = true;
    const typing = addMsg('bot', '', true);

    try{
      const res = await fetch(ENDPOINT, {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({messages: history})
      });
      const data = await res.json();
      // replace typing with reply
      typing.row.remove();
      const reply = data.reply || data.error || 'Sorry, something went wrong.';
      history.push({role:'assistant', content: reply});
      addMsg('bot', reply);
      if(!open){ badge.style.display = 'block'; }
    }catch(err){
      typing.row.remove();
      addMsg('bot','Network error. Please try again.');
      if(!open){ badge.style.display = 'block'; }
    }finally{
      sendBtn.disabled = false;
    }
  });
})();
</script>

   


    


</body>
</html>
